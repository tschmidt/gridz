class Gridz
  # Nothing to see here.
end